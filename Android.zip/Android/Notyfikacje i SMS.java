package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.core.app.NotificationCompat;
public class MainActivity extends AppCompatActivity {
    private int notificationId = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCreateActionNotification = (Button) findViewById(R.id.button);
        btnCreateActionNotification.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String id = "id_product";
                NotificationManager notificationManager;
                //sprawdzam czy numer SDK mojego projektu jest większy lub rowny Android O (OREO)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    //musze rozpoczac od uruchomienia managera powiadomien
                    notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                    //jezeli notyfikacja nie korzysta a intencji trzecich to nie potrzeba dodawac uprawnien
                    //natomiast, jezeli notyfikacja ma korzystac z mapy to juz potrzeba jej uprawnien

                    //buduje intencje powrotu:
                    //jezeli wracam do okna glownego to intencja kieruje na MainActivity
                    //jezel otwieram intencje, to wskazuje ktora
                    Intent intent1 = new Intent(getApplicationContext(), ResultActivity.class);
                    PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 123, intent1, PendingIntent.FLAG_UPDATE_CURRENT);


                  //Builder buduje powiadomienie
                    NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(getApplicationContext(), "id_product")
                            .setSmallIcon(R.drawable.ic_launcher)
                            .setBadgeIconType(NotificationCompat.BADGE_ICON_NONE)
                            .setChannelId(id)
                            .setContentTitle(/*extras.get("nt").toString()*/ "Informacja")
                            .setAutoCancel(true).setContentIntent(pendingIntent)
                            .setNumber(1)
                            .setColor(255)
                            .setContentText("Halo tu notyfikacja"/*extras.get("nm").toString()*/)
                            .setWhen(System.currentTimeMillis());
                    notificationManager.notify(1, notificationBuilder.build());
                }
            }

        });

    }


    public void createNotification() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Intent intent = new Intent(this, ResultActivity.class);
            PendingIntent pIntent = PendingIntent.getActivity(this, 0, intent, 0);

            Bitmap icon = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);

            Notification noti = new NotificationCompat.Builder(this)
                    .setContentTitle("Wiadomość")
                    .setContentText("Temat wiadomości")
                    .setTicker("Masz wiadomość")
                    .setSmallIcon(android.R.drawable.ic_media_play)
                    .setLargeIcon(icon)
                    .setAutoCancel(true)
                    .setContentIntent(pIntent)
                    .build();

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

            notificationManager.notify(0, noti);
        }
    }

    public void sendSMS(Activity activity, String msg){
        PendingIntent pi = PendingIntent.getActivity(activity, 0, new  Intent(activity, MainActivity.class), 0);
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage("5556", null, msg, pi, null);

    }
}