package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    Button button;
    EditText nameText, emailText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=(Button) findViewById(R.id.button);
        nameText=(EditText)findViewById(R.id.nameText);
        emailText=(EditText)findViewById(R.id.emailText);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    SQLiteDatabase baza=null;
                    baza=openOrCreateDatabase("baza.db", MODE_PRIVATE, null);
                    baza.execSQL("CREATE TABlE IF NOT EXISTS Person(FirstName VARCHAR, Email VARCHAR)");
                    baza.execSQL("INSERT INTO Person VALUES('"+nameText.getText()+"', '"+emailText.getText()+"')");

                    ContentValues wierszDoBazy=new ContentValues();
                    wierszDoBazy.put("FirstName", String.valueOf(nameText.getText()));
                    wierszDoBazy.put("Email", String.valueOf(emailText.getText()));
                    baza.insert("Person", null,wierszDoBazy );
                    //zwracana jest tablica asocjacyjna
                    /*
                    Nazwa kolumny zamiast numeru kolumny
                    a obok wartości

                    Mamy wiele wynikow, nie wiemy ile ich jest, wiec uzywamy petli while lub do-while albo for kiedy wiesz ile wierszy otrzymasz
                     */


                    Cursor cursor = baza.rawQuery("SELECT * FROM Person", null);
                    if (cursor.moveToFirst()){
                        do {
                            String imie=cursor.getString(cursor.getColumnIndex("imie"));

                        }while (cursor.moveToNext());
                        baza.close();
                    }
                }catch(SQLException e){

                }


                /*
                  prawo dostepu  WRITE_EXTERNAL_STORAGE
                 */

                if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
                    //dostepna jest karta pamieci
                    File plik=new File(getExternalFilesDir(Environment.DIRECTORY_RINGTONES), "plik.csv");


                }else{
                    //brak karty SD i co dalej
                }

            }
        });
    }


}