package com.example.lokalizator;


import android.content.Context;
import android.content.Intent;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;


import android.net.Uri;
import android.widget.Toast;
import android.widget.RadioButton;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.TextView;

import android.view.Menu;
import android.view.MenuItem;
//pakiet activity zawiera metody obsluguj�ce proces dzialania aplikacji
import android.app.Activity;
import android.app.PendingIntent;
//pakiet Bundle pozwala na przechowywanie informacji dla aplikacji
import android.os.Bundle;

import android.os.Bundle;

/*
 * Na pierwszy ogie� poszed� GPS. Je�eli chcemy, aby nasza aplikacja mog�a odbiera� informacje o lokalizacji, musimy poprosi� od odpowiednie uprawnienia. W zwi�zku z tym do pliku AndroidManifest.xml dopisujemy:

 
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
 

Nast�pnie musimy si� dobra� do obiektu klasy LocationManager, umo�liwiaj�cej dost�p do us�ug lokalizacyjnych, zaimplementowa� interfejs LocationListenera oraz zarejestrowa� go we wspomnianym obiekcie LocationManagera.

Interfejs LocationListenera sk�ada si� z czterech metod:

    void onLocationChanged(Location pLocation) - wywo�ywanej za ka�dym razem, 
    	gdy pozycja urz�dzenia ulegnie zmianie
    
    onProviderDisabled(String pProvider) - wywo�ywanej za ka�dym razem, 
    	kiedy dostawca o nazwie pProvider zostanie przez u�ytkownika wy��czony
    void onProviderEnabled (String pProvider) - wywo�ywanej za ka�dym razem,
     gdy u�ytkownik uruchomi dostawc� o podanej nazwie
    void onStatusChanged (String pProvider, int pStatus, Bundle pExtras) - wywo�ywanej za ka�dym razem, 
    	gdy status dostawcy o nazwie pProvider ulegnie zmianie. 
    	Status po zmianie przechowywane jest w parametrze pStatus i mo�e przyj�� jedn� z trzech warto�ci:
        OUT_OF_SERVICE - je�eli dostawca jest niedost�pny i w najbli�szej przysz�o�ci si� to nie zmieni
        TEMPORARILY_UNAVAILABLE - je�eli dostawca jest niedost�pny, lecz za chwil� si� to zmieni
        AVAILABLE - je�eli dostawca jest dost�pny
        
    Z parametru pExtras mo�emy odczyta� liczb� satelit�w, wykorzystanych do wygenerowania pozycji

*/
 

public class MainActivity extends Activity implements OnClickListener,  LocationListener {

	private LocationManager lm;
	private static String lokalizacja;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		 lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

	//	 LocationListener nale�y zarejestrowa� w LocationManagerze. Zrobimy to za pomoc� poni�szego kodu:
	        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, this);
	   /*
	    * Pierwszym parametrem metody requestLocationUpdates jest nazwa po��danego przez nas dostawcy -
	    *  oczywi�cie chodzi o GPS. Kolejnym jest minimalny okres pomi�dzy kolejnymi 
	    *  powiadomieniami wyra�ony w milisekundach. Poniewa� moja aplikacja jest we wczesnej 
	    *  fazie rozwojowej czas ten ustawi�em na 0, lecz programi�ci systemu zalecaj� nie 
	    *  schodzi� poni�ej 60000 milisekund ale kto ich s�ucha. 
	    *  Ostatnim parametrem jest LocationListener, do kt�rego kierowane s� powiadomienia

		Warto doda�, �e, zar�wno wyci�ganie LocationManagera jak i rejestracja LocationListenera
		 odbywa si� w metodzie onResume().
	    */
	   
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		 menu.add(1, 1, 1, "Uruchom onet"); //polecenie dodania kolejnego elementu, id_grupy, id_elementu, nr_pozycji, nazwa
	        menu.add(1, 2, 2, "Uruchom Google");
	        menu.add(1, 3, 3, "Zadzwon");
	        menu.add(1, 4, 4, "Komunikat na ekranie");
	        menu.add(1, 5, 5, "SMS z lokalizacja");
	        menu.add(1, 6, 6, "Zakoncz");
		return true;
	}

	public static void uruchomWebBrowser(Activity activity)
    {
    	//Intecja, to abstrakcyjny opis operacji do wykonania
    	/*predefiniowane aktywnosc
    	 * ACTION_VIEW uruchomienie przegldarki WWW
    	 * ACTION_WEB_SEARCH uruchomienie wyszukiwarki WWW
    	 * ACTION_DIAL klawiatura do wpisania numeru
    	 * ACTION_CALL polaczenie z numerem telefonu np 601-601-601
    	 * ACTION_VIEW wyswietlenie mapy dla wspolrzednych lat i lon np geo:lat,long?z=zoom
    	 */
    	Intent intencja =new Intent(Intent. ACTION_VIEW); 
	    intencja.setData(Uri. parse( "http://m.onet.pl" ));
	    activity.startActivity(intencja); // uruchomienie danej aktywnosci
    }
    
    public static void uruchomWebSearch(Activity activity)
    {
	    Intent intencja = new Intent(Intent.ACTION_WEB_SEARCH );
	    intencja.setData(Uri. parse ("http://www.google.com" ));
	    activity.startActivity(intencja);
    }
    
    public  static  void dial(Activity activity)
    {
	    Intent intencja = new Intent(Intent. ACTION_DIAL );
	    activity.startActivity(intencja);
    }
    
    public static void pokazKomunikat(Activity activity){
    //	String s = (rb1.isChecked() ?"opcja1 ": "opcja2 ");
    	
  //  	Toast toast = Toast.makeText(activity, "hej, wybrana opcja to "+s, Toast.LENGTH_LONG);
    	
    	
   // 	toast.show();
    }
    
    public  static  void sendSMS(Activity activity)
    {
    	//Pierwsze co to trzeba dodac uprawnienia ACCESS_FINE_LOCATION (permission) w zak�adce Permision dla androidmanifest
    	//wyslanie zmiany lokalizacji poprzez DDMS->Emulator Control->na dole wysylanie pozycji
    	
    	if (lokalizacja!=null){
    			Toast toast = Toast.makeText(activity, "Twoja pozycja to: "+lokalizacja, Toast.LENGTH_LONG);
    			toast.show();
    	
    	//w celu wyslania SMS nalezy dodac prawo android.permission.SEND_SMS
    	
    		/*
    		 * W celu wys�ania wiadomo�ci u�ywamy klasy SmsManager, kt�rej instancj�
    		 *  otrzymamy wywo�uj�c jej statyczn� metod� getDefault().
    		 *   Opr�cz numeru telefonu i tre�ci wiadomo�ci, do funkcji sendTextMessage 
    		 *   przekazujemy obiekt PendingIntent. Obiekt ten opakowuje wspomniany 
    		 *   wcze�niej Intent ��cz�c wersj� podstawow� (komunikat) z akcj�
    		 *    docelow� jak startActivity() lub broadcastIntent(). U�ywany jest do 
    		 *    identyfikacji celu, kt�ry ma by� zrealizowany w p�niejszym czasie.
    		 *     Oznacza to, �e po wys�aniu wiadomo�ci mo�emy na przyk�ad uruchomi� 
    		 *     nast�pn� aktywno��. W naszym wypadku wskazujemy jednak na bie��c�
    		 *      (new Intent(this, MainActivity.class)), dlatego po wys�aniu SMS nic si� nie stanie.
    		 * 
    		 */
			 
			 /*PendingIntent pozwala okre�la� akcj�, kt�ra zostanie wykonana w przysz�o�ci.
			 Umo�liwia przekazanie intencji do innej aplikacji i pozwala tej aplikacji na wykonanie
			 tej intencji tak, jakby mia�a te same uprawnienia co nasza aplikacja,
			 niezale�nie od tego, czy w momencie wykonania intencji aplikacja ta jest uruchomiona,
			 czy nie. Obiekty PendingIntent pozwalaj� na prac� aplikacji nawet po zako�czeniu jej procesu. 
			 Wa�ne jest, aby zapami�ta�, �e nawet je�eli aplikacja, kt�ra utworzy�a PendingIntent, 
			 zostanie zako�czona, intencja nadal mo�e dzia�a�.
			 */
    	
    			PendingIntent pi = PendingIntent.getActivity(activity, 0, new  Intent(activity, MainActivity.class), 0);
    			SmsManager sms = SmsManager.getDefault();


//tu wysylam na swoj port, jest to numer widoczny w emulatorze, najlepiej otworzyc drugie okno i ogl�da� wynik :)
/*
Metoda wymaga podania nast�puj�cych parametr�w:

-destinationAddress � numer telefonu odbieraj�cego wiadomo��.

-scAddress � adres centrum wiadomo�ci z sieci; powinien niemal zawsze by� ustawiony na null, co powoduje pobranie domy�lnego numeru.

-destinationPort � numer portu w telefonie odbiorcy.

-data � tre�� wiadomo�ci.

-sentIntent � obiekt PendingIntent uruchamiany po udanym wys�aniu wiadomo�ci.

-deliveryIntent � obiekt PendingIntent wywo�ywany, gdy wiadomo�� zostanie odebrana.
*/
//W sumie moze byc bez pi, a tam null
    			sms.sendTextMessage("5556", null, "Twoja lokalizacja to: "+lokalizacja, pi, null);
		
    	}
    }
    
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		/*int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}*/
		// Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	switch (item.getItemId()){
	    	case 1: uruchomWebBrowser	(this); break;
	    	case 2: uruchomWebSearch(this); break;
	    	case 3: dial(this); break;
	    	case 4: pokazKomunikat(this); break;
	    	case 5: sendSMS(this); break;
	    	case 6: this.finish(); break;
    	}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		boolean checked = ((RadioButton) v).isChecked();

		switch (v.getId()){
		case 1:
			break;
			/*case R.id.radioButton1:
				if (checked) {
					rb1.setChecked(true);rb2.setChecked(false);
				}else{ 
					rb1.setChecked(false);rb2.setChecked(true);
				}
				
				break;
			case R.id.radioButton2:
				if (checked) {
					rb2.setChecked(true);rb1.setChecked(false);
				}else{ 
					rb2.setChecked(false);rb1.setChecked(true);
				}
				break;*/
		}
	}
	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		String lat = String.valueOf(location.getLatitude());

        String lon = String.valueOf(location.getLongitude());

      //Log.e - rejestruje bledy, zobaczymy je w konsoli LogCat w Eclipse
        Log.e("GPS", "location changed: lat="+lat+", lon="+lon);
        
        lokalizacja = lat+" "+lon;
    	
    	
	}


	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
		Log.e("GPS", "status changed to " + provider + " [" + status + "]");
	}


	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		Log.e("GPS", "provider enabled " + provider);
	}


	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		Log.e("GPS", "provider disabled " + provider);
	}
}
