package com.example.nm;

import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.widget.RadioButton;
import android.view.View.OnClickListener;
import android.view.View;
//Konieczne jesli chce korzystac z kontrolki TextView.
import android.widget.TextView;
//pojawi si� gdy b�dzie tryb zgodnosci
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
//pakiet activity zawiera metody obsluguj�ce proces dzialania aplikacji
import android.app.Activity;
//pakiet Bundle pozwala na przechowywanie informacji dla aplikacji
import android.os.Bundle;


public class MainActivity extends ActionBarActivity implements OnClickListener{
	private static RadioButton 	rb1	;
	private RadioButton rb2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        rb1= (RadioButton) this.findViewById(R.id.radioButton1);
        rb1.setText("Opcja1");
        rb2 = (RadioButton) this.findViewById(R.id.radioButton2);
        rb2.setText("Opcja2");
        rb1.setOnClickListener(this);
        rb2.setOnClickListener(this);
    }

    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        menu.add(1, 1, 1, "Uruchom onet"); //polecenie dodania kolejnego elementu, id_grupy, id_elementu, nr_pozycji, nazwa
        menu.add(1, 2, 2, "Uruchom Google");
        menu.add(1, 3, 3, "Zadzwon");
        menu.add(1, 4, 4, "Komunikat na ekranie");
        menu.add(1, 5, 5, "Zakoncz");
        return true;  // spowodowanie wy�wietlenia menu
    }

    public static void uruchomWebBrowser(Activity activity)
    {
    	//Intecja, to abstrakcyjny opis operacji do wykonania
    	/*predefiniowane aktywnosc
    	 * ACTION_VIEW uruchomienie przegldarki WWW
    	 * ACTION_WEB_SEARCH uruchomienie wyszukiwarki WWW
    	 * ACTION_DIAL klawiatura do wpisania numeru
    	 * ACTION_CALL polaczenie z numerem telefonu np 601-601-601
    	 * ACTION_VIEW wyswietlenie mapy dla wspolrzednych lat i lon np geo:lat,long?z=zoom
    	 */
    	Intent intencja =new Intent(Intent. ACTION_VIEW); 
	    intencja.setData(Uri. parse( "http://m.onet.pl" ));
	    activity.startActivity(intencja); // uruchomienie danej aktywnosci
    }
    
    public static void uruchomWebSearch(Activity activity)
    {
	    Intent intencja = new Intent(Intent.ACTION_WEB_SEARCH );
	    intencja.setData(Uri. parse ("http://www.google.com" ));
	    activity.startActivity(intencja);
    }
    
    public  static  void dial(Activity activity)
    {
	    Intent intencja = new Intent(Intent. ACTION_DIAL );
	    activity.startActivity(intencja);
    }
    
    public static void pokazKomunikat(Activity activity){
    	String s = (rb1.isChecked() ?"opcja1 ": "opcja2 ");
    	
    	Toast toast = Toast.makeText(getApplicationContext(), "hej, wybrana opcja to "+s, Toast.LENGTH_LONG);
    	
    	
    	toast.show();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	switch (item.getItemId()){
    	case 1: uruchomWebBrowser	(this); break;
    	case 2: uruchomWebSearch(this); break;
    	case 3: dial(this); break;
    	case 4: pokazKomunikat(this); break;
    	case 5: this.finish(); break;
    	}
    	/*}
        if (id == R.id.action_settings) {
            return true;
        }*/
        return super.onOptionsItemSelected(item);
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		boolean checked = ((RadioButton) v).isChecked();

		switch (v.getId()){
		
			case R.id.radioButton1:
				if (checked) {
					rb1.setChecked(true);rb2.setChecked(false);
				}else{ 
					rb1.setChecked(false);rb2.setChecked(true);
				}
				
				break;
			case R.id.radioButton2:
				if (checked) {
					rb2.setChecked(true);rb1.setChecked(false);
				}else{ 
					rb2.setChecked(false);rb1.setChecked(true);
				}
				break;
		}
	}
}
