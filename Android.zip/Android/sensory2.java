package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private TextView textView;

    private Button przepiszButton;
    private EditText srcEditText, dstEditText;

    private Button setValueButton;
    private EditText valEditText;
    private ProgressBar progressBar;
    private SensorManager sensorManager;
    private Sensor sensor;
    List<Sensor> sList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView=(TextView) findViewById(R.id.textView);
        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
                //pobieram liste sensorow
                sList = sensorManager.getSensorList(Sensor.TYPE_ALL);
                //czytam ta liste, pobierajac z kazdego sensora: typ, producenta oraz wersje sensora
                for (int i = 1; i < sList.size(); i++) {
                    textView.setVisibility(View.VISIBLE);
                    textView.append("\n" + sList.get(i).getName() + "\n" + sList.get(i).getVendor() + 
						" " + sList.get(i).getVersion() + "\n");
                }
                sList.clear();
                //czyszcze liste na potrzeby pobrania listy akcelerometrow
                sList = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
                if (sList.size() > 1)//sprawdzam czy na liscie pokazal sie akcelerometr
                {
                    //podpinam sobie do obiektu sensor akcelerometr
                    sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                    //podpinam listenera z dolu
                   // SensorEventListener mySensorEventListener;
                    sensorManager.registerListener(mySensorEventListener, sensor, SensorManager.SENSOR_DELAY_NORMAL);
                } else {
                    Toast.makeText(getBaseContext(), "Error: No accelerometers", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    protected void onStop() {
        if (sList.size() > 1) {
            sensorManager.unregisterListener(mySensorEventListener);
            sList.clear();
        }
        super.onStop();
    }


    private SensorEventListener mySensorEventListener = new SensorEventListener() {

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            //sprawdzam typ eventu do jakiego sensora nalezy
            if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                getAccelerometer(sensorEvent);//wywoluje metode do obslugi akcelerometru
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }

        //wlasna metoda obslugi danych eventowych z akcelerometru
        private void getAccelerometer(SensorEvent event) {
            float[] values = event.values;


            //akcelerometr zwraca zawsze 3 wartosci przyspieszenia na kazdej z osi
            float x = values[0];
            float y = values[1];
            float z = values[2];
			
        }
    };
}

